
### Expected Behavior


### Actual Behavior





### Environment
- vue.js version: <version here>
- vue-chart.js version: <version here>
- npm version: <version here>
