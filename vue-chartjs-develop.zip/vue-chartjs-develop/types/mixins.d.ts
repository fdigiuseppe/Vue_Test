import Vue from 'vue'

export declare class ReactiveDataMixin extends Vue {
  chartData: any;
}

export declare class ReactivePropMixin extends Vue {
  readonly chartData: any;
}
