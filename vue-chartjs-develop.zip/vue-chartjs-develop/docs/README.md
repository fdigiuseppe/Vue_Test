---
home: true
heroImage: /vue-chartjs.png
actionText: Get Started →
actionLink: /guide/
features:
- title: Easy
  details: Easy for both beginners and pros 🙌
- title: Extendable
  details: Simple to use, easy to extend 💪
- title: Powerfull
  details: With the full power of chart.js 💯
footer: MIT Licensed | Copyright © 2018-present Jakub Juszczak
---
